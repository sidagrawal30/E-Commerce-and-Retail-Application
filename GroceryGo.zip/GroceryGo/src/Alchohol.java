

//import bo.ProductBO;
//import util.Factory;
//import util.TakeInput;

public class Alchohol implements UICategory {
	@Override
	public void category() {
		String categories[] = { "Whiskey", "Wine", "Vodka" };
		Factory.getStyle().printMenu("Alchohol", categories, false);
		int choice = TakeInput.takeChoice(categories.length);
		ProductBO productBO = Factory.getProductBO();
		switch (choice) {
		case 1:
			UI.printSubCategory(productBO.getWhiskey(), "WHISKEY");
			break;
		case 2:
			UI.printSubCategory(productBO.getWine(), "WINE");
			break;
		case 3:
			UI.printSubCategory(productBO.getVodka(), "VODKA");
			break;
		}
	}
}