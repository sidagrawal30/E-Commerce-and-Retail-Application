

//import mainFunctionality.Cart;
//import util.wishlistLinkedList;
//import util.Factory;
//import util.Style;

public class wishlistBO {
	private wishlistLinkedList wish;

	public wishlistBO() {
		this.wish = new wishlistLinkedList();
	}

	public void add(Cart cart) {
		wish.add(cart);
	}

	public void remove(int index) {
		resetID(index - 1, wish.remove(index - 1).getId());
	}

	public void removeRange(int from, int to) {
		int id = wish.get(from - 1).getId();
		wish.removeRange(from - 1, to);
		resetID(from - 1, id);
	}

	public void changeQuantity(int index, int quantity) {
		wish.get(index - 1).setQuantity(quantity);
	}

	public int getNextId() {
		return wish.size() + 1;
	}

	public boolean isEmpty() {
		return wish.isEmpty();
	}

	public double display() {
		double totalCost = 0;
		Style style = Factory.getStyle();
		style.cartHeading();
		for (Cart cart : wish) {
			style.cartDetail(cart);
			totalCost += cart.getCost();
		}
		return totalCost;
	}

	public void displayBill() {
		Style style = Factory.getStyle();
		style.printTotal(wish.size(), display());
	}

	private void resetID(int index, int id) {
		while (index < wish.size()) {
			wish.get(index++).setId(id++);
		}
	}
}