
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;

//import mainFunctionality.Cart;
//import product.Product;

public class Style {

    public void printMenu(String heading, String[] categories, boolean isHome) {
        System.out.println("\nGroceryGo - Your Go To Solution for At Home Grocery" + "\n" +heading);
        for (int i = 0; i < categories.length; i++) {
            System.out.println("   " + (i + 1) + ". " + categories[i]);
        }
        if (!isHome) {
            System.out.println("   9. Home Page");
        }
        System.out.println("   0. Exit");
    }

    public void printMenu(String heading, LinkedList<Product> list) {
        System.out.println("\nGroceryGo - Your Go To Solution for At Home Grocery" + "\n" +heading);
        for (int i = 0; i < list.size(); i++) {
            Product product = list.get(i);
            System.out.printf("   %d. %-17s $%.2f%n", i + 1, product.getName(), product.getPrice());
        }
        System.out.println("   0. Exit");
    }

    public void printHeading(String s) {
        System.out.println("\n\u2B50 " + s);
    }

    public void printName(String shopName) {
        System.out.println("=".repeat(50));
        System.out.println(shopName);
        System.out.println("=".repeat(50));
    }

    public void printStyle(String s) {
        System.out.println("   ➤ " + s);
    }

    public void successMsg(String msg) {
        System.out.println("\n✅ " + msg + "\n");
    }

    public void cartHeading() {
        
        System.out.printf("\n█ %-10s█ %-40s█ %-26s█ %-14s█ %-26s%n", "SI.No.", "Item", "Cost ($)", "Quantity", "Total");
        
    }

    public void printTotal(int quantity, double totalCost) {
        System.out.println();
        
        System.out.printf("█ %-81s█   %02d      █   $%.2f        █%n", " ", quantity, totalCost);
        System.out.printf("█ %-81s█ GST 18%%:       █   $%.2f        █%n", " ", (totalCost * 18) / 100);
        System.out.printf("█ %-81s█ Grand Total:  █   $%.2f        █%n", " ", (totalCost * 18) / 100 + totalCost);
        
    }

    public void cartDetail(Cart cart) {
        System.out.print(cart);
    }


    public void printStyleWithBorder(String s) {
        System.out.println("=".repeat(50));
        System.out.println(s);
        System.out.println("=".repeat(50));
    }

    public void printDateAndTime() {
        Date date = new Date();
        System.out.printf("   Date: %s%n", new SimpleDateFormat("dd MMMM yyyy").format(date));
        System.out.println("=".repeat(70));
        System.out.printf("   Time: %s%n", new SimpleDateFormat("hh:mm:ss a").format(date));
        
    }

    public void thanksMsg() {
        System.out.println();
        System.out.println("=".repeat(130));
        System.out.println("=".repeat(130));
        System.out.println("=".repeat(50));
       
        System.out.println("=".repeat(50));
        System.out.println("=".repeat(50));
        System.out.println("   Thank you for shopping at GroceryGo");
        System.out.println("=".repeat(50));
        System.out.println("   Have a Great Day!");
        System.out.println("=".repeat(50));
        System.out.println("   Visit us again soon...");
        System.out.println("=".repeat(50));
        
        System.out.println();
    }
}
