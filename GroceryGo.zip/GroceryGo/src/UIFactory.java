
public class UIFactory {
	public static UICategory getUI(String s) {
		if (s.equalsIgnoreCase("Fresh Grocery")) {
			return new FreshGrocery();
		} else if (s.equalsIgnoreCase("Snacks")) {
			return new Snacks();
		} else if (s.equalsIgnoreCase("Health")) {
			return new Health();
		} else if (s.equalsIgnoreCase("Pantry")) {
			return new Pantry();
		} else if (s.equalsIgnoreCase("Alchohol")) {
			return new Alchohol();
		}
		return null;
	}
}
