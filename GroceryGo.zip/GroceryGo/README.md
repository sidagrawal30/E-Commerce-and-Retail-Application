# E-Commerce Console Base

It's build on Core Java

**Tools: Eclipse**

## ScreenShot

![Login Page](screenshots/home.png)
![Login Page](screenshots/c1.png)
![Login Page](screenshots/product.png)
![Login Page](screenshots/add2cart.png)
![Login Page](screenshots/cart.png)
![Login Page](screenshots/bill.png)
