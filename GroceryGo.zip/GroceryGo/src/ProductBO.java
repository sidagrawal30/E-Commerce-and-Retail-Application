

import java.util.LinkedList;

//import product.Product;

public class ProductBO {
	private LinkedList<Product> products;

	public ProductBO() {
		products = new LinkedList<>();
	}

	public LinkedList<Product> getBars() {
		products.clear();
		products.add(new Product("Kirkland", 2));
		products.add(new Product("Quest", 5));
		products.add(new Product("Nature's Valley", 2));
		products.add(new Product("Powerbar", 3));
		return products;
	}

	public LinkedList<Product> getDairy() {
		products.clear();
		products.add(new Product("Milk", 2));
		products.add(new Product("Yogurt", 5));
		products.add(new Product("Eggs", 8));
		products.add(new Product("Cheese", 6));
		return products;
	}

	public LinkedList<Product> getMeat() {
		products.clear();
		products.add(new Product("Chicken", 12));
		products.add(new Product("Fish", 15));
		products.add(new Product("Pork", 14));
		products.add(new Product("Beef", 10));
		return products;
	}

	public LinkedList<Product> getSauces() {
		products.clear();
		products.add(new Product("Ketchup", 7));
		products.add(new Product("Mustard", 8));
		products.add(new Product("Ranch", 9));
		products.add(new Product("Thousand Island", 6));
		return products;
	}

	public LinkedList<Product> getFruits() {
		products.clear();
		products.add(new Product("Apples", 3));
		products.add(new Product("Oranges", 4));
		products.add(new Product("Bananas", 2));
		products.add(new Product("Strawberries", 5));
		return products;
	}

	public LinkedList<Product> getCereal() {
		products.clear();
		products.add(new Product("Cornflakes", 10));
		products.add(new Product("Cocoa Puffs", 11));
		products.add(new Product("Honey Crunch", 12));
		products.add(new Product("Fruit Loops", 11));
		return products;
	}

	public LinkedList<Product> getVegetables() {
		products.clear();
		products.add(new Product("Tomatoes", 3));
		products.add(new Product("Potatoes", 4));
		products.add(new Product("Onions", 2));
		products.add(new Product("Spinach", 5));
		products.add(new Product("Mushrooms", 6));
		return products;
	}

	public LinkedList<Product> getWine() {
		products.clear();
		products.add(new Product("Red", 18));
		products.add(new Product("White", 26));
		products.add(new Product("Rose", 30));
		return products;
	}

	public LinkedList<Product> getWhiskey() {
		products.clear();
		products.add(new Product("Jameson", 25));
		products.add(new Product("Jim Beam", 30));
		products.add(new Product("Red Label", 50));
		products.add(new Product("Black Label", 75));
		return products;
	}
	
	public LinkedList<Product> getVodka() {
        products.clear();
        products.add(new Product("Svedka", 18));
        products.add(new Product("Absolut", 32));
        products.add(new Product("Grey Goose", 55));
        products.add(new Product("Smirnoff", 27));
        return products;
    }

    public LinkedList<Product> getCookies() {
        products.clear();
        products.add(new Product("Chips Ahoy", 7));
        products.add(new Product("Lotus Biscoff", 11));
        products.add(new Product("Oreo", 6));
        products.add(new Product("Nutter Butter", 3));
        return products;
    }

    public LinkedList<Product> getIcecream() {
        products.clear();
        products.add(new Product("Chocolate", 5));
        products.add(new Product("Strawberry", 6));
        products.add(new Product("Vanilla", 5));
        products.add(new Product("Cookie and Cream", 7));
        return products;
    }

    public LinkedList<Product> getPasta() {
        products.clear();
        products.add(new Product("Penne", 2));
        products.add(new Product("Spaghetti", 2));
        products.add(new Product("Macceroni", 3));
        products.add(new Product("Farfalle", 3));
        return products;
    }

    public LinkedList<Product> getHygiene() {
        products.clear();
        products.add(new Product("Toothbrush", 4));
        products.add(new Product("After Shave", 8));
        products.add(new Product("Body Wash", 13));
        products.add(new Product("Deodrant", 20));
        return products;
    }

    public LinkedList<Product> getBaby() {
        products.clear();
        products.add(new Product("Diapers", 16));
        products.add(new Product("Wet Wipes", 9));
        products.add(new Product("Baby Food", 25));
        products.add(new Product("Teethter", 13));
        return products;
    }

    public LinkedList<Product> getChips() {
        products.clear();
        products.add(new Product("Lays", 4));
        products.add(new Product("Cheetos", 3));
        products.add(new Product("Dorritos", 5));
        products.add(new Product("Funyuns", 4));
        return products;
    }

    public LinkedList<Product> getMedicines() {
        products.clear();
        products.add(new Product("Painkillers", 10));
        products.add(new Product("Allergy", 7));
        products.add(new Product("Antibiotics", 15));
        products.add(new Product("Contraceptive", 12));
        return products;
    }

    public LinkedList<Product> getSweets() {
        products.clear();
        products.add(new Product("Hersheys", 6));
        products.add(new Product("Lindt", 12));
        products.add(new Product("Ressee's", 8));
        products.add(new Product("KitKat", 5));
        return products;
    }
}
