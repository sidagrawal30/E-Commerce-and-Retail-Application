

public interface UICategory {
	void category();
}
