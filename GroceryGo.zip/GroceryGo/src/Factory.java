

//import bo.CartBO;
//import bo.ProductBO;

public class Factory {
	private static Style style = new Style();
	private static final String SHOP_NAME = "GroceryGo - Your Go To Solution for At Home Grocery";
	private static CartBO cartBO = new CartBO();
	private static ProductBO productBO = new ProductBO();
	private static wishlistBO wishlistBO = new wishlistBO();

	public static Style getStyle() {
		return style;
	}

	public static String getShopName() {
		return String.format("%-25s", SHOP_NAME);
	}

	public static CartBO getCartBO() {
		return cartBO;
	}
	
	public static wishlistBO getwishlistBO() {
		return wishlistBO;
	}

	public static ProductBO getProductBO() {
		return productBO;
	}

}
