

//import bo.ProductBO;
//import util.Factory;
//import util.TakeInput;

public class Health implements UICategory {

	@Override
	public void category() {
		String categories[] = { "Medicines", "Hygiene", "Baby" };
		Factory.getStyle().printMenu("Health", categories, false);
		int choice = TakeInput.takeChoice(categories.length);
		ProductBO productBO = Factory.getProductBO();
		switch (choice) {
		case 1:
			UI.printSubCategory(productBO.getMedicines(), "Medicines");
			break;
		case 2:
			UI.printSubCategory(productBO.getHygiene(), "Hygiene");
			break;
		case 3:
			UI.printSubCategory(productBO.getBaby(), "Baby");
			break;
		}
	}
}
