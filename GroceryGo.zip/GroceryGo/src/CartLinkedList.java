

import java.util.LinkedList;

//import mainFunctionality.Cart;

public class CartLinkedList extends LinkedList<Cart> {
    private static final long serialVersionUID = 1L;

    @Override
    public void removeRange(int fromIndex, int toIndex) {
        super.subList(fromIndex, toIndex).clear();
    }
}
