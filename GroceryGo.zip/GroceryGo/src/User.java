

import java.util.LinkedList;
import java.util.Queue;

public class User {
    private String name;
    private String mobileNo;
    private Queue<String> queue;

    public User() {
        queue = new LinkedList<String>();
    }

    public User(String name, String mobileNo) {
        this.name = name;
        this.mobileNo = mobileNo;
        queue = new LinkedList<String>();
    }

    public void addToQueue(String item) {
        queue.offer(item);
    }

    public String removeFromQueue() {
        return queue.poll();
    }

    public String peekQueue() {
        return queue.peek();
    }

    public boolean isQueueEmpty() {
        return queue.isEmpty();
    }

    public String getName() {
        return String.format("%-25s", name);
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }
}
