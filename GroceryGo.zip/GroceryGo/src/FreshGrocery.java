
//import bo.ProductBO;
//import util.Factory;
//import util.TakeInput;

public class FreshGrocery implements UICategory {

	@Override
	public void category() {
		String categories[] = { "Fruits", "Vegetables", "Meat", "Dairy" };
		Factory.getStyle().printMenu("FRESH GROCERY", categories, false);
		int choice = TakeInput.takeChoice(categories.length);
		ProductBO productBO = Factory.getProductBO();
		switch (choice) {
		case 1:
			UI.printSubCategory(productBO.getFruits(), "FRUITS");
			break;
		case 2:
			UI.printSubCategory(productBO.getVegetables(), "VEGETABLES");
			break;
		case 3:
			UI.printSubCategory(productBO.getMeat(), "MEAT");
			break;
		case 4:
			UI.printSubCategory(productBO.getDairy(), "DAIRY");
			break;
		}
	}
}
