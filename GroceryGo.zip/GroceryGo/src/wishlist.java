
import java.util.LinkedList;
import java.util.Queue;

public class wishlist {
	private int id;
	private String itemName;
	private double cost;
	private int quantity;
	private double total;

	public wishlist(int id, String itemName, double cost, int quantity) {
		super();
		this.id = id;
		this.itemName = itemName;
		this.cost = cost;
		this.quantity = quantity;
		this.total = cost * quantity;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
		total = cost * quantity;
	}

	public String getItemName() {
		return itemName;
	}

	public double getCost() {
		return cost;
	}

	public int getQuantity() {
		return quantity;
	}

	public double getTotal() {
		return total;
	}

	@Override
	public String toString() {
		return String.format(
				"\n\u2588    %02d\t    \u2588 %-40s \u2588   %09.2f\t\t    \u2588   %02d\t     \u2588   %09.02f\t\t \u2588",
				id, itemName, cost, quantity, total);
	}

	public static void main(String[] args) {
		Queue<wishlist> queue = new LinkedList<wishlist>();
		queue.offer(new wishlist(1, "Apple AirPods", 1700, 2));
		queue.offer(new wishlist(2, "Bolt", 499, 1));
		queue.offer(new wishlist(3, "Philips", 299, 4));
		
		// Printing the items in the wishlist
		System.out.println("Items in the wishlist:");
		for (wishlist wishlist : queue) {
			System.out.println(wishlist);
		}
	}
}
