

//import bo.ProductBO;
//import util.Factory;
//import util.TakeInput;

public class Snacks implements UICategory {
	@Override
	public void category() {
		String categories[] = { "Chips", "Sweets", "Cookies", "Bars", "Icecream" };
		Factory.getStyle().printMenu("SNACKS", categories, false);
		int choice = TakeInput.takeChoice(categories.length);
		ProductBO productBO = Factory.getProductBO();
		switch (choice) {
		case 1:
			UI.printSubCategory(productBO.getChips(), "Chips");
			break;
		case 2:
			UI.printSubCategory(productBO.getSweets(), "Sweets");
			break;
		case 3:
			UI.printSubCategory(productBO.getCookies(), "Cookies");
			break;
		case 4:
			UI.printSubCategory(productBO.getBars(), "Bars");
			break;
		case 5:
			UI.printSubCategory(productBO.getIcecream(), "Icecream");
			break;
		}
	}
}
